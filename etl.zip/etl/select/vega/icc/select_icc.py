import os
import sys

import pyspark.sql.functions as F

current_date_str = sys.argv[1]
print(current_date_str)
script_name = 'airflow_select_vega_{}'.format(current_date_str)

# specify spark version, java version, python version
spark_home = "/usr/hdp/current/spark2-client"
java_home = "/usr/java/default"
python_path = '/apps/anaconda2/bin/python'

# set environment variables
os.environ['SPARK_HOME'] = spark_home
os.environ['JAVA_HOME'] = java_home
os.environ['PYSPARK_PYTHON'] = python_path
spark_python = os.path.join(spark_home, 'python')
# py4j = glob.glob(os.path.join(spark_python, 'lib', 'py4j-*.zip'))[0]
py4j = "/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip"
sys.path[:0] = [spark_python, py4j]

PYSPARK_SUBMIT_ARGS_CUSTOM = "--master yarn-client --driver-cores 1 --driver-memory 1g \
    --num-executors 2 --executor-cores 4 --executor-memory 8g --conf spark.port.maxRetries=100"

os.environ['PYSPARK_SUBMIT_ARGS'] = (PYSPARK_SUBMIT_ARGS_CUSTOM
                                     + " --name {}".format(script_name)
                                     + " pyspark-shell")

# launching PySpark application
execfile(os.path.join(spark_home, 'python/pyspark/shell.py'))

icc_og_call_dir = '/rawdata/icc/icc_og_call/date={}'.format(current_date_str)
icc_og_sms_call_dir = '/rawdata/icc/icc_og_sms_call/date={}'.format(current_date_str)
output_dir = '/data/processed/vega/icc/date={}'.format(current_date_str)
column_list = [
    "acc_profile",

    "AMOUNT_SWAPPED",

    "BONUS_CREDIT2_CONSUMED",

    "BONUS_CREDIT2_REMAINING",

    "BONUS_CREDIT3_CONSUMED",

    "BONUS_CREDIT3_REMAINING",

    "BONUS_IRA_CONSUMED",

    "BONUS_IRA_REMAINING",

    "BONUS_IRB_CONSUMED",

    "BONUS_IRB_REMAINING",

    "bonus_IRSMS_consumed",

    "bonus_IRSMS_remaining",

    "BONUS_IRVS_CONSUMED",

    "BONUS_IRVS_REMAINING",

    "BONUS_KM1_CONSUMED",

    "BONUS_KM1_REMAINING",

    "BONUS_KM1T_CONSUMED",

    "BONUS_KM1T_REMAINING",

    "BONUS_KM1V_CONSUMED",

    "BONUS_KM1V_REMAINING",

    "BONUS_KM2_CONSUMED",

    "BONUS_KM2_REMAINING",

    "BONUS_KM2T_CONSUMED",

    "BONUS_KM2T_REMAINING",

    "BONUS_KM2V_CONSUMED",

    "BONUS_KM2V_REMAINING",

    "BONUS_KM3_CONSUMED",

    "BONUS_KM3_REMAINING",

    "BONUS_KM3T_CONSUMED",

    "BONUS_KM3T_REMAINING",

    "BONUS_KM3V_CONSUMED",

    "BONUS_KM3V_REMAINING",

    "BONUS_KM4_CONSUMED",

    "BONUS_KM4_REMAINING",

    "BONUS_KM4T_CONSUMED",

    "BONUS_KM4T_REMAINING",

    "BONUS_KM4V_CONSUMED",

    "BONUS_KM4V_REMAINING",

    "BONUS_KMDK1_CONSUMED",

    "BONUS_KMDK1_REMAINING",

    "BONUS_KMDK2_CONSUMED",

    "BONUS_KMDK2_REMAINING",

    "BONUS_KMDK3_CONSUMED",

    "BONUS_KMDK3_REMAINING",

    "BONUS_KMDK4_CONSUMED",

    "BONUS_KMDK4_REMAINING",

    "bonus_TK1_consumed",

    "bonus_TK1_remaining",

    "BUNDLE_CREDIT1_CONSUMED",

    "BUNDLE_CREDIT1_REMAINING",

    "BUNDLE_CS_CONSUMED",

    "BUNDLE_CS_REMAINING",

    "bundle_DATA_31_consumed",

    "bundle_DATA_31_remaining",

    "bundle_DATA_6_remaining",

    "bundle_DATA_6_consumed",

    "bundle_DATA_KM1_consumed",

    "bundle_DATA_KM1_remaining",

    "bundle_DATA_LN_consumed",

    "bundle_DATA_LN_remaining",

    "bundle_DATA_VC_consumed",

    "bundle_DATA_VC_remaining",

    "bundle_DATA5_consumed",

    "bundle_DATA5_remaining",

    "bundle_DataDem_consumed",

    "bundle_DataDem_remaining",

    "bundle_DataZ1_consumed",

    "bundle_DataZ1_remaining",

    "bundle_DataZ2_consumed",

    "bundle_DataZ2_remaining",

    "bundle_DataZ3_consumed",

    "bundle_DataZ3_remaining",

    "BUNDLE_DK_CONSUMED",

    "BUNDLE_DK_REMAINING",

    "BUNDLE_GPRS0_CONSUMED",

    "BUNDLE_GPRS0_REMAINING",

    "bundle_GROUP_consumed",

    "bundle_GROUP_remaining",

    "BUNDLE_IRD_CONSUMED",

    "BUNDLE_IRD_REMAINING",

    "BUNDLE_KM_CONSUMED",

    "BUNDLE_KM_REMAINING",

    "BUNDLE_KM99T_CONSUMED",

    "BUNDLE_KM99T_REMAINING",

    "bundle_KMKNDL_consumed",

    "bundle_KMKNDL_remaining",

    "BUNDLE_KMPACK_CONSUMED",

    "BUNDLE_KMPACK_REMAINING",

    "BUNDLE_LM_CONSUMED",

    "BUNDLE_LM_REMAINING",

    "BUNDLE_LM_DL_CONSUMED",

    "BUNDLE_LM_DL_REMAINING",

    "bundle_LM1_consumed",

    "bundle_LM1_remaining",

    "bundle_LN_consumed",

    "bundle_LN_remaining",

    "bundle_mloyalty_consumed",

    "bundle_mloyalty_remaining",

    "BUNDLE_OP_CONSUMED",

    "BUNDLE_OP_REMAINING",

    "BUNDLE_PACKAGE_CONSUMED",

    "BUNDLE_PACKAGE_REMAINING",

    "BUNDLE_RM_CONSUMED",

    "BUNDLE_RM_REMAINING",

    "bundle_SMS_SP1_consumed",

    "bundle_SMS_SP1_remaining",

    "bundle_SMS_SP2_consumed",

    "bundle_SMS_SP2_remaining",

    "bundle_SMS3_consumed",

    "bundle_SMS3_remaining",

    "bundle_SMSRefill_consumed",

    "bundle_SMSRefill_remaining",

    "BUNDLE_THOAILM1_CONSUMED",

    "BUNDLE_THOAILM1_REMAINING",

    "BUNDLE_TK_AP1_CONSUMED",

    "BUNDLE_TK_AP1_REMAINING",

    "BUNDLE_TK_AP2_CONSUMED",

    "BUNDLE_TK_AP2_REMAINING",

    "bundle_VIDEO_consumed",

    "bundle_VIDEO_remaining",

    "BUNDLE_VNPT_CONSUMED",

    "BUNDLE_VNPT_REMAINING",

    "BUNDLE_VNPT1_CONSUMED",

    "BUNDLE_VNPT1_REMAINING",

    "BUNDLE_VOICE_KM1_CONSUMED",

    "BUNDLE_VOICE_KM1_REMAINING",

    "BUNDLE_VOICE_LMZ_CONSUMED",

    "BUNDLE_VOICE_LMZ_REMAINING",

    "BUNDLE_VOICE_SP1_CONSUMED",

    "BUNDLE_VOICE_SP1_REMAINING",

    "BUNDLE_VOICE_SP2_CONSUMED",

    "BUNDLE_VOICE_SP2_REMAINING",

    "BUNDLE_VOICETH_CONSUMED",

    "BUNDLE_VOICETH_REMAINING",

    "BUNDLE_VORMO_IN_CONSUMED",

    "BUNDLE_VORMO_IN_REMAINING",

    "BUNDLE_WALLET1_CONSUMED",

    "BUNDLE_WALLET1_REMAINING",

    "BUNDLE_WALLET2_CONSUMED",

    "BUNDLE_WALLET2_REMAINING",

    "bundle_WALLET3_consumed",

    "bundle_WALLET3_remaining",

    "bundle_wifi_consumed",

    "bundle_wifi_remaining",

    "call_sta_time",

    "call_type",

    "called_isdn",

    "calling_isdn",

    "CELL_ID",

    "correlation_identifier",

    "credit_before_adjustment",

    "credit_charged",

    "credit_remaining",

    "DAY_SWAPPED",

    "DURATION",

    "EVENT_TYPE_NAME",

    "FEE_SWAPPED",

    "feeName",

    "IMSI",

    "LOCATION",

    "LOCATION_INDICATOR",

    "NET_ELEMENT_ID",

    "NET_ELEMENT_TRANS_ID",

    "network_service_id",

    "ORG_CALL_ID",

    "REASON_CODE",

    "Reseller_ID",

    "ROUTE_NUMBER",

    "SCRATCH_NUMBER",

    "SCRATCH_TYPE",

    "SCRATCH_VALUE",

    "SubScriber_type",

    "TARIFF_NAME",

    "topup_profile",

    "TRANSACTION_DESCRIPTION",

    "PLMN_ID",

    "CALL_TYPE_ID",

    "DISCARDED_CREDIT",

    "INSERVICERESULT"
]

df1 = spark.read.format("csv").option("header","true").load('/data/processed/vega/vega_100k_enc.csv')
#df_icc_og_call = spark.read.format("csv").option("header","true").option("delimiter","|").load(icc_og_call_dir)#.toDF(*column_list)
#df_icc_og_sms_call =spark.read.format("csv").option("header","true").option("delimiter","|").load(icc_og_sms_call_dir)#.toDF(*column_list)
df_icc_og_call = spark.read.format("csv").load(icc_og_call_dir).toDF(*column_list)
df_icc_og_sms_call = spark.read.format("csv").load(icc_og_sms_call_dir).toDF(*column_list)
df = df_icc_og_call.union(df_icc_og_sms_call)
join_df = (df.alias('df').join(df1.alias('df1'),
                               on = df["CALLING_ISDN"] == df1["ISDN"],
                               how = 'inner')
                         .select('df.*'))

df_summary = join_df.select([
    'CALLING_ISDN',
    'CALLED_ISDN',
    'PLMN_ID',
    'CALL_TYPE_ID',
    'CALL_STA_TIME',
    'DURATION',
    'CREDIT_CHARGED',
    'CREDIT_REMAINING',
    'CALL_TYPE',
    'INSERVICERESULT',
    'ORG_CALL_ID'
]).withColumn('HEAD_CALLED_ISDN', F.substring(F.regexp_replace('CALLED_ISDN', r'^[0]*', ''), 1, 3))

df_summary.write.mode("overwrite").csv(output_dir)

# Write checksum file
log_count = df_summary.count()
print(log_count)

# 1 day file size: 1.2 GB compress, or 11 GB uncompress
