import os
import sys

import pyspark.sql.functions as F

current_date_str = sys.argv[1]

script_name = 'airflow_select_vitri_psc_{}'.format(current_date_str)

# specify spark version, java version, python version
spark_home = "/usr/hdp/current/spark2-client"
java_home = "/usr/java/default"
python_path = '/apps/anaconda2/bin/python'

# set environment variables
os.environ['SPARK_HOME'] = spark_home
os.environ['JAVA_HOME'] = java_home
os.environ['PYSPARK_PYTHON'] = python_path
spark_python = os.path.join(spark_home, 'python')
# py4j = glob.glob(os.path.join(spark_python, 'lib', 'py4j-*.zip'))[0]
py4j = "/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip"
sys.path[:0] = [spark_python, py4j]

PYSPARK_SUBMIT_ARGS_CUSTOM = "--master yarn-client --driver-cores 1 --driver-memory 1g \
    --num-executors 1 --executor-cores 2 --executor-memory 2g"

os.environ['PYSPARK_SUBMIT_ARGS'] = (PYSPARK_SUBMIT_ARGS_CUSTOM
                                     + " --name {}".format(script_name)
                                     + " pyspark-shell")

# launching PySpark application
execfile(os.path.join(spark_home, 'python/pyspark/shell.py'))

input_dir = '/rawdata/vitripsc_daily/date={}'.format(current_date_str)

column_list = [
"file_date", "isdn", 
    "province_code", 
    "district_code", 
    "is_psc_data"
]

df = spark.read.format("csv").load(input_dir).toDF(*column_list)
df1 = spark.read.format("csv").option("header","True").load('/data/processed/vega/vega_100k_enc.csv')

df_summary = df.join(df1, on ="ISDN", how= "inner").select(*column_list)

# put_file_to_local_service.put_file(hdfs_dir=input_dir, file_path=file_path, compressed_file_path=compressed_file_path)

output_dir = '/data/processed/vega/vitripsc_daily/date={}'.format(current_date_str)
df_summary.coalesce(8).write.mode('overwrite').csv(output_dir)

# Write checksum file
log_count = df_summary.count()
print(log_count)

# 1 day file size: 1.2 GB compress, or 11 GB uncompress
