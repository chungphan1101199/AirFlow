import os
import sys

import pyspark.sql.functions as F

current_date_str = sys.argv[1]

script_name = 'airflow_select_sub_{}'.format(current_date_str)

# specify spark version, java version, python version
spark_home = "/usr/hdp/current/spark2-client"
java_home = "/usr/java/default"
python_path = '/apps/anaconda2/bin/python'

# set environment variables
os.environ['SPARK_HOME'] = spark_home
os.environ['JAVA_HOME'] = java_home
os.environ['PYSPARK_PYTHON'] = python_path
spark_python = os.path.join(spark_home, 'python')
# py4j = glob.glob(os.path.join(spark_python, 'lib', 'py4j-*.zip'))[0]
py4j = "/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip"
sys.path[:0] = [spark_python, py4j]

PYSPARK_SUBMIT_ARGS_CUSTOM = "--master yarn-client --driver-cores 1 --driver-memory 1g \
    --num-executors 1 --executor-cores 2 --executor-memory 2g"

os.environ['PYSPARK_SUBMIT_ARGS'] = (PYSPARK_SUBMIT_ARGS_CUSTOM
                                     + " --name {}".format(script_name)
                                     + " pyspark-shell")

# launching PySpark application
execfile(os.path.join(spark_home, 'python/pyspark/shell.py'))
column_list =[
    "sub_id", 
       "isdn",
       "name",
       "sex",
       "birth_date", 
       "address",
       "id_no", 
       "address_bill",
       "sta_datetime",
       "end_datetime",
       "mob_type",
       "status",
       "sub_type"
]
input_dir = '/rawdata/sub/date={}'.format(current_date_str)

df = spark.read.format("csv").load(input_dir).toDF(*column_list)

df.createOrReplaceTempView('subs_info')
df1 = spark.read.format("csv").option("header","True").load('/data/processed/vega/vega_100k_enc.csv')
column_list2 =[
        "ISDN",
       "sta_datetime",
       "end_datetime",
       "mob_type",
        "head",
       "birth_date",
       "status",
       "sex",
       "sub_type"
]

df_summary = spark.sql('''
SELECT isdn,
       sta_datetime,
       end_datetime,
       mob_type,
       SUBSTR (isdn,1, 3) head,
       birth_date,
       status,
       sex,
       sub_type
  FROM subs_info
''').join(df1, on ="ISDN", how= "inner").select(*column_list2)

output_dir = '/data/processed/vega/sub/date={}'.format(current_date_str)
df_summary.coalesce(8).write.mode('overwrite').csv(output_dir)

# Write checksum file

log_count = df_summary.count()
print(log_count)
