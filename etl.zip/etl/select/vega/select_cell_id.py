import os
import sys
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from etl.select.cic import put_file_to_local_service
import pyspark.sql.functions as F

current_date_str = sys.argv[1]
first_date_of_month_str = (
    (datetime.strptime(current_date_str, '%Y-%m-%d') ).replace(day=1)).strftime(
    '%Y-%m-%d')

script_name = 'airflow_select_cell_id_{}'.format(first_date_of_month_str)

# specify spark version, java version, python version
spark_home = "/usr/hdp/current/spark2-client"
java_home = "/usr/java/default"
python_path = '/apps/anaconda2/bin/python'

# set environment variables
os.environ['SPARK_HOME'] = spark_home
os.environ['JAVA_HOME'] = java_home
os.environ['PYSPARK_PYTHON'] = python_path
spark_python = os.path.join(spark_home, 'python')
# py4j = glob.glob(os.path.join(spark_python, 'lib', 'py4j-*.zip'))[0]
py4j = "/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip"
sys.path[:0] = [spark_python, py4j]

PYSPARK_SUBMIT_ARGS_CUSTOM = "--master yarn-client --driver-cores 1 --driver-memory 1g \
    --num-executors 1 --executor-cores 2 --executor-memory 2g"

os.environ['PYSPARK_SUBMIT_ARGS'] = (PYSPARK_SUBMIT_ARGS_CUSTOM
                                     + " --name {}".format(script_name)
                                     + " pyspark-shell")

# launching PySpark application
execfile(os.path.join(spark_home, 'python/pyspark/shell.py'))

input_dir = '/rawdata/cell_id/date={}'.format(first_date_of_month_str)

column_list = [
"file_date",
"mcc",
"mnc",
"lac",
"cell_id",
"cell_name",
"bts_name",
"location_number",
"center",
"province_code",
"district_code",
"province",
"district",
"address_detail",
"address_detail_english",
"latitude",
"longitude",
"cell_type",
"azimuth",
"imported_date"
]

df = spark.read.format("csv").load(input_dir).toDF(*column_list)
df.createOrReplaceTempView('cell_info')
column_list2 =[
"file_date",
"mcc",
"mnc",
"lac",
"cell_id",
"bts_name",
"center",
"province_code",
"district_code",
"province",
"district",
"cell_type",
"imported_date"
]

df_summary = spark.sql('''
select
file_date,
mcc,
mnc,
lac,
cell_id,
bts_name,
center,
province_code,
district_code,
province,
district,
cell_type,
imported_date
     from cell_info
''').select(*column_list2)

# put_file_to_local_service.put_file(hdfs_dir=input_dir, file_path=file_path, compressed_file_path=compressed_file_path)

output_dir = '/data/processed/common/cell_id/date={}'.format(first_date_of_month_str)
df_summary.write.mode('overwrite').csv(output_dir)

# Write checksum file
log_count = df_summary.count()
print(log_count)

# 1 day file size: 1.2 GB compress, or 11 GB uncompress
