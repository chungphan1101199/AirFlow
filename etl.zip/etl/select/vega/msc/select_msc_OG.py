import os
import sys
import pyspark.sql.functions as F

current_date_str = sys.argv[1]
script_name = 'airflow_select_msc_for_og_dv_' + current_date_str

# specify spark version, java version, python version
spark_home = "/usr/hdp/current/spark2-client"
java_home = "/usr/java/default"
python_path = '/apps/anaconda2/bin/python'

# set environment variables
os.environ['SPARK_HOME'] = spark_home
os.environ['JAVA_HOME'] = java_home
os.environ['PYSPARK_PYTHON'] = python_path
spark_python = os.path.join(spark_home, 'python')
# py4j = glob.glob(os.path.join(spark_python, 'lib', 'py4j-*.zip'))[0]
py4j = "/usr/hdp/current/spark2-client/python/lib/py4j-0.10.7-src.zip"
sys.path[:0] = [spark_python, py4j]

PYSPARK_SUBMIT_ARGS_CUSTOM = "--master yarn-client --driver-cores 1 --driver-memory 1g \
    --num-executors 2 --executor-cores 4 --executor-memory 8g --conf spark.port.maxRetries=100 "

os.environ['PYSPARK_SUBMIT_ARGS'] = (PYSPARK_SUBMIT_ARGS_CUSTOM
                                     + " --name {}".format(script_name)
                                     + " pyspark-shell")

# launching PySpark application
execfile(os.path.join(spark_home, 'python/pyspark/shell.py'))

# Actually we combine OG and DV
df1 = spark.read.format("csv").option("header","true").load('/data/processed/vega/vega_100k_enc.csv')
dv_input_dir = '/data/msc_phan_huong/dv/date={}'.format(current_date_str)
og_input_dir = '/data/msc_phan_huong/og/date={}'.format(current_date_str)
output_dir = '/data/processed/vega/msc/og/date={}'.format(current_date_str)
df_og = spark.read.format("csv").option("header", "true").load(og_input_dir)
df = df_og
try:
    df_dv = spark.read.format("csv").option("header", "true").load(dv_input_dir)
    df = df_dv.union(df_og)
except Exception as e:
    print(e)

join_df = (df.alias('df').join(df1.alias('df1'),
                               on = df["CALLING_ISDN"] == df1["ISDN"],
                               how = 'inner')
                         .select('df.*'))
df_summary = join_df.select([
    'CALLING_ISDN',
    'CALLED_ISDN',
    'PLMN_ID',
    'CALL_TYPE_ID',
    'CALL_STA_TIME',
    'DURATION',
    'CELL_ID',
    'CALLING_IMEI',
    'ORG_CALL_ID'
]).withColumn('HEAD_CALLED_ISDN', F.substring(F.regexp_replace('CALLED_ISDN', r'^[0]*', ''), 1, 3))

df_summary.write.mode("overwrite").csv(output_dir)

# Write checksum file
log_count = df_summary.count()
print(log_count)
