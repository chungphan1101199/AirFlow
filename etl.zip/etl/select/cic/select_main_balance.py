import sys

import pyspark.sql.functions as F

from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = 'main_balance'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '2g',
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_select_{}_{}'.format(data_source, current_date_str)
)

input_dir = '/rawdata/main_balance/date={}'.format(current_date_str)
check_sum_output_dir = '/data/processed/cic/checksum/main_balance/date={}'.format(current_date_str)

df = spark.read.format("csv").load(input_dir)

# Write checksum file
log_count = df.count()

df_checksum = spark.read.format("csv").option("header", "true").load(
    '/data/processed/cic/checksum/template/sample_checksum.csv')
df_checksum = df_checksum.withColumn('log_count', F.lit(log_count))
df_checksum.write.mode("overwrite").csv(check_sum_output_dir)

# 1 day file size: 1.2 GB compress, or 11 GB uncompress
