import sys

from etl.select.cic import put_check_sum_file_to_local_service

current_date_str = sys.argv[1]

hdfs_dir = '/data/processed/cic/checksum/recharge/date={}'.format(current_date_str)
file_path = '/ftp/mhtt/mvas_cic/checksum/checksum.recharge.{}.csv'.format(current_date_str)

put_check_sum_file_to_local_service.put_file(hdfs_dir=hdfs_dir, file_path=file_path)
