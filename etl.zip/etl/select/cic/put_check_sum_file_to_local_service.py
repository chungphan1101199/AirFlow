import os
import sys

from etl.fetch_from_db.utils import hdfs


def put_file(hdfs_dir, file_path):
    if hdfs.check_dir_exist(hdfs_dir):
        print ('Directory already exist in HDFS: {}'.format(hdfs_dir))
        print('try to download')
        hdfs.get_merge_file_to_local(hdfs_dir, file_path)

        if os.path.isfile(file_path):
            print("File exist, success")
        else:
            print("File not exist: {}".format(file_path))
            sys.exit(1)
    else:
        print ('Fail as directory not exist in HDFS {}'.format(hdfs_dir))
        sys.exit(1)
