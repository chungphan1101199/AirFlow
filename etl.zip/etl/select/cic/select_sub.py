import os
import sys

import pyspark.sql.functions as F

from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = 'sub'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '2g',
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_select_{}_{}'.format(data_source, current_date_str)
)

column_list = [
    "sub_id",
    "isdn",
    "name",
    "sex",
    "birth_date",
    "address",
    "id_no",
    "address_bill",
    "sta_datetime",
    "end_datetime",
    "mob_type",
    "status",
    "sub_type"
]
input_dir = '/rawdata/sub/date={}'.format(current_date_str)
check_sum_output_dir = '/data/processed/cic/checksum/sub/date={}'.format(current_date_str)

df = spark.read.format("csv").load(input_dir).toDF(*column_list)

df.createOrReplaceTempView('subs_info')

df_summary = spark.sql('''
SELECT isdn,
       sta_datetime,
       end_datetime,
       mob_type,
       SUBSTR (isdn,1, 3) head,
       birth_date,
       status,
       sex,
       sub_type
  FROM subs_info
''')

# Write checksum file
log_count = df.count()

output_dir = '/data/processed/cic/sub/date={}'.format(current_date_str)
df_summary.coalesce(8).write.mode('overwrite').csv(output_dir)

# Write checksum file

check_sum_output_dir = '/data/processed/cic/checksum/sub/date={}'.format(current_date_str)
log_count = df_summary.count()
print(log_count)
df_checksum = spark.read.format("csv").option("header", "true").load(
    '/data/processed/cic/checksum/template/sample_checksum.csv')
df_checksum = df_checksum.withColumn('log_count', F.lit(log_count))
df_checksum.write.mode("overwrite").csv(check_sum_output_dir)
# 1 day file size: 1.2 GB compress, or 11 GB uncompress
