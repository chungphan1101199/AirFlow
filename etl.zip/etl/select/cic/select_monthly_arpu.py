import sys
from datetime import datetime

import pyspark.sql.functions as F
from dateutil.relativedelta import relativedelta

from etl.common import init_spark

current_date_str = sys.argv[1]
first_date_of_previous_month_str = (
    (datetime.strptime(current_date_str, '%Y-%m-%d') - relativedelta(months=1)).replace(day=1)).strftime(
    '%Y-%m-%d')

script_name = 'airflow_select_monthly_arpu_{}'.format(first_date_of_previous_month_str)

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '2g',
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name=script_name
)

input_dir = '/rawdata/monthly_arpu/date={}'.format(first_date_of_previous_month_str)
check_sum_output_dir = '/data/processed/cic/checksum/monthly_arpu/date={}'.format(first_date_of_previous_month_str)

column_list = [
    "ISSUE_MONTH",
    "SUB_TYPE",
    "ISDN",
    "CREDIT",
    "BONUS",
    "CREDIT_VAT",
    "BONUS_VAT",
    "ITEM_ID",
    "CENTER",
    "PROVINCE_CODE",
    "DISTRICT_CODE",
    "REGISTER_DATE",
    "ACC_PROFILE",
    "TOTAL_CALL",
    "TOTAL_DURATION",
    "SUB_ITEM_ID",
    "IS_COPORATE",
    "IS_MULTI",
    "SUB_ID",
    "MNP_FROM_ID",
    "BUS_TYPE",
    "SUBS_TYPE"
]

df = spark.read.format("csv").load(input_dir).toDF(*column_list)
df.createOrReplaceTempView('revenue_sub_monthly')
df_summary = spark.sql('''
select
          issue_month,
          isdn,

          SUM(credit_vat) arpu,
          SUM(CASE WHEN item_id IN (30,31,32,33,34,39) THEN credit_vat ELSE 0 END) arpu_data,
          SUM(CASE WHEN item_id IN (14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,37,38,67) THEN credit_vat ELSE 0 END) arpu_sms,
          SUM(CASE WHEN item_id IN (35,36,37,38,39,61) THEN credit_vat ELSE 0 END) arpu_cvqt,
          SUM(CASE WHEN item_id IN (1,2,3,4,5,6,7,8,9,10,11,12,13,35,36,66,64) THEN credit_vat ELSE 0 END) arpu_thoai,
          SUM(CASE WHEN item_id IN (1,2,3,4,5,6,7,8,9,11,12,13,66) THEN credit_vat ELSE 0 END) arpu_thoai_trong_nuoc,
          SUM(CASE WHEN item_id IN (10,64) THEN credit_vat ELSE 0 END) arpu_thoai_quoc_te,
          SUM(CASE WHEN item_id IN (14,15,16,17,18,19,20,21,22,24,25,26,27,28,29,67) THEN credit_vat ELSE 0 END) arpu_sms_trong_nuoc,
          SUM(CASE WHEN item_id IN (23) THEN credit_vat ELSE 0 END) arpu_sms_quoc_te,

          SUM(CASE WHEN item_id IN (1,2,3,4,5,6,7,8,9,10,11,12,13,35,36,66,64) THEN total_duration ELSE 0 END) ll_thoai,
          SUM(CASE WHEN item_id IN (1) THEN total_duration ELSE 0 END) ll_thoai_noi_mang,
          SUM(CASE WHEN item_id IN (3,6) THEN total_duration ELSE 0 END) ll_thoai_viettel,
          SUM(CASE WHEN item_id IN (5) THEN total_duration ELSE 0 END) ll_thoai_vinaphone,
          SUM(CASE WHEN item_id IN (7) THEN total_duration ELSE 0 END) ll_thoai_vietnamobile,
          SUM(CASE WHEN item_id IN (2,4,8,9) THEN total_duration ELSE 0 END) ll_thoai_khac,

          SUM(CASE WHEN item_id IN (14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,37,38,67) THEN total_call ELSE 0 END) ll_sms,
          SUM(CASE WHEN item_id IN (14) THEN total_call ELSE 0 END) ll_sms_noi_mang,
          SUM(CASE WHEN item_id IN (16,19) THEN total_call ELSE 0 END) ll_sms_viettel,
          SUM(CASE WHEN item_id IN (18) THEN total_call ELSE 0 END) ll_sms_vina,
          SUM(CASE WHEN item_id IN (20) THEN total_call ELSE 0 END) ll_sms_vietnamobile,
          SUM(CASE WHEN item_id IN (15,17,21,22) THEN total_call ELSE 0 END) ll_sms_khac
     from revenue_sub_monthly
         where to_date(issue_month)= '{}'
         group by issue_month, isdn

'''.format(first_date_of_previous_month_str))

# put_file_to_local_service.put_file(hdfs_dir=input_dir, file_path=file_path, compressed_file_path=compressed_file_path)

output_dir = '/data/processed/cic/monthly_arpu/date={}'.format(first_date_of_previous_month_str)
df_summary.coalesce(8).write.mode('overwrite').csv(output_dir)

# Write checksum file
log_count = df_summary.count()
print(log_count)
df_checksum = spark.read.format("csv").option("header", "true").load(
    '/data/processed/cic/checksum/template/sample_checksum.csv')
df_checksum = df_checksum.withColumn('log_count', F.lit(log_count))
df_checksum.write.mode("overwrite").csv(check_sum_output_dir)

# 1 day file size: 1.2 GB compress, or 11 GB uncompress
