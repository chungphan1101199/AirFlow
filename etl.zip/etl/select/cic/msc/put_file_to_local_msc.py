import sys

from etl.select.cic import put_file_to_local_service

current_date_str = sys.argv[1]
data_type = sys.argv[2].lower()

hdfs_dir = '/data/processed/cic/msc/{}/date={}'.format(data_type, current_date_str)
file_path = '/ftp/mhtt/mvas_cic/msc/{}/msc.{}.{}.csv'.format(data_type, data_type, current_date_str)
compressed_file_path = file_path + '.bz2'

put_file_to_local_service.put_file(hdfs_dir=hdfs_dir, file_path=file_path, compressed_file_path=compressed_file_path)
