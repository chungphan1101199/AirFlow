import os
import sys
import pyspark.sql.functions as F

from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = 'msc_OG'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 4,
    "executor.memory": '8g',
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_select_{}_{}'.format(data_source, current_date_str)
)

# Actually we combine OG and DV
dv_input_dir = '/data/msc_phan_huong/dv/date={}'.format(current_date_str)
og_input_dir = '/data/msc_phan_huong/og/date={}'.format(current_date_str)
output_dir = '/data/processed/cic/msc/og/date={}'.format(current_date_str)
check_sum_output_dir = '/data/processed/cic/checksum/msc/og/date={}'.format(current_date_str)

df_dv = spark.read.format("csv").option("header", "true").load(dv_input_dir)
df_og = spark.read.format("csv").option("header", "true").load(og_input_dir)

df = df_dv.union(df_og)

df = df.select([
    'CALLING_ISDN',
    'CALLED_ISDN',
    'PLMN_ID',
    'CALL_TYPE_ID',
    'CALL_STA_TIME',
    'DURATION',
    'CELL_ID',
    'CALLING_IMEI',
    'ORG_CALL_ID'
]).withColumn('HEAD_CALLED_ISDN', F.substring(F.regexp_replace('CALLED_ISDN', r'^[0]*', ''), 1, 3))

df.write.mode("overwrite").csv(output_dir)

# Write checksum file
log_count = df.count()

df_checksum = spark.read.format("csv").option("header", "true").load(
    '/data/processed/cic/checksum/template/sample_checksum.csv')
df_checksum = df_checksum.withColumn('log_count', F.lit(log_count))
df_checksum.write.mode("overwrite").csv(check_sum_output_dir)
