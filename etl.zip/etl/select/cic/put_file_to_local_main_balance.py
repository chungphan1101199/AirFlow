import sys

from etl.select.cic import put_file_to_local_service

current_date_str = sys.argv[1]

hdfs_dir = '/rawdata/main_balance/date={}'.format(current_date_str)
file_path = '/ftp/mhtt/mvas_cic/main_balance/main_balance.{}.csv'.format(current_date_str)
compressed_file_path = file_path + '.bz2'

put_file_to_local_service.put_file(hdfs_dir=hdfs_dir, file_path=file_path, compressed_file_path=compressed_file_path)
