import os
import sys

from etl.common import execute_command_service
from etl.fetch_from_db.utils import hdfs


def put_file(hdfs_dir, file_path, compressed_file_path):
    if hdfs.check_dir_exist(hdfs_dir):
        print ('Directory exist in HDFS: {}'.format(hdfs_dir))
        if os.path.isfile(compressed_file_path):
            print("Compressed File exists and is readable")
            args = ['rm', '-rfv', compressed_file_path]
            return_code = execute_command_service.execute(args)
            print ('exit code of remove old file: {}'.format(return_code))
        else:
            print("Compress file not exist ")

        print('try to download and compress')
        hdfs.get_merge_file_to_local(hdfs_dir, file_path)
        
        if os.path.isfile(file_path):
            print("File exist, try to compress")
            print ('File to compress: {}'.format(file_path))
            args = ['bzip2', '-fv', file_path]
            return_code = execute_command_service.execute(args)
            sys.exit(return_code)
        else:
            print("File not exist: {}".format(file_path))
            sys.exit(1)

    else:
        print ('Directory not exist in HDFS, execute make dir: {}'.format(hdfs_dir))
        sys.exit(1)
