df_unrate_icc_og_sms_call.where('credit_charged > 0 AND discarded_credit = 0 AND inserviceresult = 0').selectExpr(
    'calling_isdn',
    'called_isdn',
    'net_element_id',
    'net_element_trans_id',
    'transaction_description',
    '''CASE
        WHEN called_isdn <> '0'
        THEN
            CASE
                WHEN LENGTH (called_isdn) < 10 THEN 'GTGT'
                ELSE 'KHAC'
            END
        WHEN UPPER (NVL (net_element_trans_id, 'abc')) = UPPER ('vp_999')
        THEN
            'Goi cuoc'
        ELSE
            'GTGT'
    END
        nhomdichvu''',

    '''CASE
        WHEN called_isdn <> '0'
        THEN
            CASE
                WHEN LENGTH (called_isdn) < 10 THEN called_isdn
                ELSE 'KHAC'
            END
        ELSE
            CASE
                WHEN UPPER (NVL (net_element_trans_id, 'abc')) =
                         UPPER ('vp_999')
                THEN
                    transaction_description
                ELSE
                    CASE
                        WHEN net_element_id = 'cps.com'
                        THEN
                            concat(split(net_element_trans_id, '[^-.]+')[0]
                            , CASE
                                   WHEN
                                    size(split(net_element_trans_id, '[^-.]+')) > 0 

                                   THEN
                                       concat('.'
                                       ,split(net_element_trans_id, '[^-.]+')[-2]
                                       )
                                   ELSE
                                       ''
                               END
                               )
                        ELSE
                            CASE
                                WHEN net_element_id LIKE
                                         'crbt%.www.huawei.com'
                                THEN
                                    'funring'
                                ELSE
                                    concat(split(net_element_trans_id, '[^-.]+')[0]
                                    ,CASE
                                           WHEN
                                            (size(split(net_element_trans_id, '[^-.]+')) > 0 )

                                           THEN
                                               concat('.',
                                               split(net_element_trans_id, '[^-.]+')[-2]
                                               )
                                           ELSE
                                               ''
                                       END
                                       )
                            END
                    END
            END
    END
        dichvu''',
).show(1000)

df_icc_og_call_other.where('''
                (scratch_value = '0-0'
                AND (credit_charged > 0
                     OR (called_isdn IN ('0121', '121')
                         AND (amount_swapped + fee_swapped) <> 0))
                AND call_type_cdr NOT IN (320, 301, 302)
                AND UPPER (
                        NVL (NVL (transaction_description, reason_code),
                             '-1')) NOT LIKE
                        UPPER ('BT145_Reason_%'))
               OR (scratch_value <> '0-0'
                   AND NVL (transaction_description, 'MobiEZ') <> 'MobiEZ'
                   AND NVL (transaction_description, 'MobiEZ') NOT LIKE
                           'BUCP:%'
                   AND NVL (transaction_description, 'MobiEZ') NOT LIKE
                           'hc_google%'
                   AND UPPER (NVL (transaction_description, 'MobiEZ')) NOT LIKE
                           UPPER ('%Selfcare%')
                   AND call_type_cdr = 415))
''').show()

df_icc_sms_content_call.where('credit_charged > 0 AND discarded_credit = 0 AND inserviceresult = 0').selectExpr(
    'CALL_STA_TIME',
    'calling_isdn',
    '"GTGT" nhomdichvu',
    'called_isdn dichvu',
    'credit_charged',
    'NULL duration',
    'NULL org_call_id').show(1000)

df_unrate_call_icc.selectExpr(
    'CALL_STA_TIME',
    'calling_isdn',
    '''CASE
        WHEN LENGTH (called_isdn) < 10 THEN 'GTGT'
        ELSE CASE WHEN TYPE = 'M' THEN 'SMS' ELSE 'Thoai' END
    END as
        TYPE''',
    'called_isdn',
    'credit_charged',
    'duration',
    '''CASE
        WHEN SUBSTR (org_call_id, 1, 4) = '0001'
             AND LENGTH (org_call_id) = 13
        THEN
            SUBSTR (org_call_id, 5)
        ELSE
            org_call_id
    END
        org_call_id'''
).show(1000)

df_icc_ic_call.selectExpr(
    'CALL_STA_TIME',
    'CALLING_ISDN',
    '"Thoai den khi CVQT" TYPE',
    'CALLED_ISDN',
    'credit_charged',
    'duration',
    'NULL org_call_id'
).show(1000)
