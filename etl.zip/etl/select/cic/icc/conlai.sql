/* Formatted on 7/28/2020 5:09:42 PM (QP5 v5.160) */
SELECT CALL_STA_TIME,
       calling_isdn,
       CASE
           WHEN called_isdn <> '0'
           THEN
               CASE
                   WHEN LENGTH (called_isdn) < 10 THEN 'GTGT'
                   ELSE 'KHAC'
               END
           WHEN UPPER (NVL (net_element_trans_id, 'abc')) = UPPER ('vp_999')
           THEN
               'Goi cuoc'
           ELSE
               'GTGT'
       END
           nhomdichvu,
       CASE
           WHEN called_isdn <> '0'
           THEN
               CASE
                   WHEN LENGTH (called_isdn) < 10 THEN called_isdn
                   ELSE 'KHAC'
               END
           ELSE
               CASE
                   WHEN UPPER (NVL (net_element_trans_id, 'abc')) =
                            UPPER ('vp_999')
                   THEN
                       transaction_description
                   ELSE
                       CASE
                           WHEN net_element_id = 'cps.com'
                           THEN
                               REGEXP_SUBSTR (net_element_trans_id,
                                              '[^-.]+',
                                              1,
                                              1)
                               || CASE
                                      WHEN REGEXP_COUNT (
                                               net_element_trans_id,
                                               '[^-.]+',
                                               1,
                                               'i')
                                           - 1 <> 0
                                      THEN
                                          '.'
                                          || REGEXP_SUBSTR (
                                                 net_element_trans_id,
                                                 '[^-.]+',
                                                 1,
                                                 REGEXP_COUNT (
                                                     net_element_trans_id,
                                                     '[^-.]+',
                                                     1,
                                                     'i')
                                                 - 1)
                                      ELSE
                                          ''
                                  END
                           ELSE
                               CASE
                                   WHEN net_element_id LIKE
                                            'crbt%.www.huawei.com'
                                   THEN
                                       'funring'
                                   ELSE
                                       REGEXP_SUBSTR (
                                           transaction_description,
                                           '[^-.]+',
                                           1,
                                           1)
                                       || CASE
                                              WHEN REGEXP_COUNT (
                                                       transaction_description,
                                                       '[^-.]+',
                                                       1,
                                                       'i')
                                                   - 1 <> 0
                                              THEN
                                                  '.'
                                                  || REGEXP_SUBSTR (
                                                         transaction_description,
                                                         '[^-.]+',
                                                         1,
                                                         REGEXP_COUNT (
                                                             transaction_description,
                                                             '[^-.]+',
                                                             1,
                                                             'i')
                                                         - 1)
                                              ELSE
                                                  ''
                                          END
                               END
                       END
               END
       END
           dichvu,
       credit_charged,
       NULL duration,
       NULL org_call_id
  FROM crc4_ct.unrate_icc_og_sms_call PARTITION (data20200701)
 -- WHERE LOWER (net_element_trans_id) LIKE 'sdp%'
 WHERE credit_charged > 0 AND discarded_credit = 0 AND inserviceresult = 0


UNION ALL
SELECT CALL_STA_TIME,
       calling_isdn,
       'GTGT' nhomdichvu,
       called_isdn dichvu,
       credit_charged,
       NULL duration,
       NULL org_call_id
  FROM crc4_ct.icc_sms_content_call PARTITION (data20200701)
 WHERE credit_charged > 0 AND discarded_credit = 0 AND inserviceresult = 0
UNION ALL


SELECT CALL_STA_TIME,
       calling_isdn,
       CASE
           WHEN scratch_value <> '0-0'
           THEN
               CASE
                   WHEN called_isdn LIKE '%UT' THEN 'Ungtien'
                   ELSE 'Nhan tien chuyen'
               END
           ELSE
               CASE
                   WHEN called_isdn IS NULL
                   THEN
                       'KHAC'
                   WHEN DECODE (called_isdn, 'D0', 'M2D', called_isdn) IN
                            ('Ungtien_900')
                   THEN
                       'Ungtien'
                   WHEN DECODE (called_isdn, 'D0', 'M2D', called_isdn) IN
                            ('M2D', 'M2U')
                   THEN
                       DECODE (called_isdn, 'D0', 'M2D', called_isdn)
                   WHEN called_isdn LIKE '%HU'
                   THEN
                       'Hoan ung'
                   ELSE
                       'Goi cuoc'
               END
       END
           nhomdichvu,
       called_isdn dichvu,
       credit_charge,
       NULL duration,
       NULL org_call_id
  FROM (SELECT                                  /*+ full(a) parallel(a,2,2) */
               CALL_STA_TIME,
               calling_isdn,
               scratch_value,
               CASE
                   WHEN scratch_value <> '0-0'
                   THEN
                       REGEXP_SUBSTR (scratch_value,
                                      '[^-]+',
                                      1,
                                      1)
                       + REGEXP_SUBSTR (scratch_value,
                                        '[^-]+',
                                        1,
                                        2)
                   ELSE
                       CASE
                           WHEN called_isdn IN ('0121', '121')
                           THEN
                               (amount_swapped + fee_swapped)
                           ELSE
                               credit_charged
                       END
               END
                   credit_charge,
               CASE
                   WHEN called_isdn IN ('0119', '119')
                   THEN
                       'M2U'
                   WHEN called_isdn IN ('0121', '121')
                   THEN
                       'M2D'
                   WHEN UPPER (transaction_description) LIKE
                            UPPER ('Ungtien%')
                   THEN
                       transaction_description
                   WHEN UPPER (event_type_name) = 'ADJUSTEMENT'
                   THEN
                       REGEXP_SUBSTR (transaction_description,
                                      '[^_]+',
                                      1,
                                      1)
                   ELSE
                       NVL (transaction_description, reason_code)
               END
                   called_isdn
          FROM crc4_ct.icc_og_call_other PARTITION (data20200701) a
         WHERE (scratch_value = '0-0'
                AND (credit_charged > 0
                     OR (called_isdn IN ('0121', '121')
                         AND (amount_swapped + fee_swapped) <> 0))
                AND call_type_cdr NOT IN (320, 301, 302)
                AND UPPER (
                        NVL (NVL (transaction_description, reason_code),
                             '-1')) NOT LIKE
                        UPPER ('BT145_Reason_%'))
               OR (scratch_value <> '0-0'
                   AND NVL (transaction_description, 'MobiEZ') <> 'MobiEZ'
                   AND NVL (transaction_description, 'MobiEZ') NOT LIKE
                           'BUCP:%'
                   AND NVL (transaction_description, 'MobiEZ') NOT LIKE
                           'hc_google%'
                   AND UPPER (NVL (transaction_description, 'MobiEZ')) NOT LIKE
                           UPPER ('%Selfcare%')
                   AND call_type_cdr = 415))
UNION ALL


SELECT CALL_STA_TIME,
       calling_isdn,
       CASE
           WHEN LENGTH (called_isdn) < 10 THEN 'GTGT'
           ELSE CASE WHEN TYPE = 'M' THEN 'SMS' ELSE 'Thoai' END
       END
           TYPE,
       called_isdn,
       credit_charged,
       duration,
       CASE
           WHEN SUBSTR (org_call_id, 1, 4) = '0001'
                AND LENGTH (org_call_id) = 13
           THEN
               SUBSTR (org_call_id, 5)
           ELSE
               org_call_id
       END
           org_call_id
  FROM crc4_ct.unrate_call_icc PARTITION (data20200701) a
UNION ALL

SELECT CALL_STA_TIME,
       calling_isdn,
       'Thoai den khi CVQT' TYPE,
       called_isdn,
       TO_NUMBER (credit_charged),
       duration,
       NULL org_call_id
  FROM crc4_ct.icc_ic_call PARTITION (data20200701) a
 WHERE NVL (duration, 0) <> 0;
