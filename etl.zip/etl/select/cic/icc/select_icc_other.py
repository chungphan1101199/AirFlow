import os
import sys

import pyspark.sql.functions as F

from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = 'icc_others'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '2g',
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_select_{}_{}'.format(data_source, current_date_str)
)

list_data_sources = (
    # Others
    'icc_ic_call',  # goi den
    'icc_og_call_other',  # cong tru tien khach hang, nap tien, rut tien ghi vao day
    'icc_sms_content_call',  # SMS den dau so 6789x
    'unrate_call_icc',  # x rate dc dau so
    'unrate_icc_og_sms_call',  # x rate dc dau so
)

df_final = None
for data_source in list_data_sources:
    try:
        input_dir = '/rawdata/icc/{}/date={}'.format(data_source, current_date_str)
        df = spark.read.format("csv").option('header', 'true').load(input_dir)
        df = df.select([
            'CALLING_ISDN',
            'CALLED_ISDN',
            'PLMN_ID',
            'CALL_TYPE_ID',
            'CALL_STA_TIME',
            'DURATION',
            'CREDIT_CHARGED',
            'CREDIT_REMAINING',
            'CALL_TYPE',
            'INSERVICERESULT',
            'ORG_CALL_ID'
        ]).withColumn('HEAD_CALLED_ISDN', F.substring(F.regexp_replace('CALLED_ISDN', r'^[0]*', ''), 1, 3)).withColumn(
            'DATA_SOURCE', F.lit(data_source))
        if data_source == 'unrate_icc_og_sms_call':
            df = df.where('CREDIT_CHARGED > 0')

        if df_final is None:
            df_final = df
        else:
            df_final = df_final.unionByName(df)
    except Exception as e:
        print ("Exception when read file for {}".format(data_source, current_date_str))
        print (e)
        continue

output_dir = '/data/processed/cic/icc_other/date={}'.format(current_date_str)
check_sum_output_dir = '/data/processed/cic/checksum/icc_other/date={}'.format(current_date_str)

df_final.write.mode("overwrite").csv(output_dir)

# Write checksum file
log_count = df_final.count()

df_checksum = spark.read.format("csv").option("header", "true").load(
    '/data/processed/cic/checksum/template/sample_checksum.csv')
df_checksum = df_checksum.withColumn('log_count', F.lit(log_count))
df_checksum.write.mode("overwrite").csv(check_sum_output_dir)
