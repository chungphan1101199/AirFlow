import glob
import sys
from datetime import datetime

from etl.fetch_from_db.utils import hdfs

current_date_str = sys.argv[1]

new_date_format = (datetime.strptime(current_date_str, '%Y-%m-%d')).strftime('%Y%m%d')

hdfs_dir = '/rawdata/icc/icc_og_sms_call/date={}'.format(current_date_str)
files_list = glob.glob('/ftp/ICC/{}_CDR_ICC_SMS*.bz2'.format(new_date_format))

if len(files_list) == 0:
    print('no file exist')
    sys.exit(1)
else:
    print('have file, continue put to HDFS: ')
    if hdfs.check_dir_exist(hdfs_dir):
        print ('Directory already exist in HDFS: {}'.format(hdfs_dir))
    else:
        print ('Directory not exist in HDFS, execute make dir: {}'.format(hdfs_dir))
        hdfs.mkdir_hdfs(hdfs_dir)

    for file_path in files_list:
        print (file_path)
        if hdfs.move_file_to_hdfs(file_path, hdfs_dir):
            print ('Sucess Move file to HDFS for {} to {}', file_path, hdfs_dir)
        else:
            print ('Cannot move file to HDFS for {} to {}', file_path, hdfs_dir)
            sys.exit(1)
