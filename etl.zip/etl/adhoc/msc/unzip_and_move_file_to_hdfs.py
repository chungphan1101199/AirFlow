import glob
import sys
from datetime import datetime

from etl.common import execute_command_service
from etl.fetch_from_db.utils import hdfs

current_date_str = sys.argv[1]
data_type = sys.argv[2]

new_date_format = (datetime.strptime(current_date_str, '%Y-%m-%d')).strftime('%Y%m%d')

# Sample file path: /ftp/MSC/20190801_CDR_MSC_IC.txt.zip
hdfs_dir = '/rawdata/msc/{}/date={}'.format(data_type.lower(), current_date_str)
bzip2_files_list = glob.glob('/ftp/MSC/{}_CDR_MSC_{}*.zip.bz2'.format(new_date_format, data_type))

if len(bzip2_files_list) == 0:
    print('no zip.bz2 file')
else:
    print('have zip.bz2 file, decompress bz2 file first')
    for bzip2_file_path in bzip2_files_list:
        args = ['bzip2', '-d', bzip2_file_path]
        execute_command_service.execute(args)

files_list = glob.glob('/ftp/MSC/{}_CDR_MSC_{}*.zip'.format(new_date_format, data_type))
if len(files_list) == 0:
    print('no file exist')
    sys.exit(1)
else:
    print('have file, continue put to HDFS: ')
    if hdfs.check_dir_exist(hdfs_dir):
        print ('Directory already exist in HDFS: {}'.format(hdfs_dir))
    else:
        print ('Directory not exist in HDFS, execute make dir: {}'.format(hdfs_dir))
        hdfs.mkdir_hdfs(hdfs_dir)

    for zip_file_path in files_list:
        # unzip file
        print("Unzip file: {}".format(zip_file_path))
        args = ['unzip', '-o', zip_file_path, '-d', '/ftp/MSC']
        return_code = execute_command_service.execute(args)

        if return_code == 0:
            # compress file
            raw_file_path = zip_file_path.replace('.zip', '')
            print ('File to compress: {}'.format(raw_file_path))
            args = ['bzip2', '-fv', raw_file_path]
            return_code = execute_command_service.execute(args)

            if return_code == 0:
                # move bz2 file to HDSF
                bzip2_file_path = zip_file_path.replace('.zip', '.bz2')
                print('bzip2 file path: {}'.format(bzip2_file_path))

                if hdfs.move_file_to_hdfs(bzip2_file_path, hdfs_dir):
                    print ('Sucess Move file to HDFS for {} to {}', bzip2_file_path, hdfs_dir)
                    print('delete local file system: ')
                    args = ['rm', '-rfv', bzip2_file_path]
                    return_code = execute_command_service.execute(args)
                    sys.exit(return_code)
                else:
                    print ('Cannot move file to HDFS for {} to {}', bzip2_file_path, hdfs_dir)
                    sys.exit(1)
            else:
                print ('fail to compress bzip2 file: {}'.format(raw_file_path))
                sys.exit(return_code)

        else:
            print ('fail to unzip file')
            sys.exit(return_code)
