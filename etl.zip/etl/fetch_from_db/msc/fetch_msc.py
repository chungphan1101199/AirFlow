import sys
from datetime import datetime
from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = sys.argv[2]
script_name = 'airflow_fetch_msc_for_{}_{}'.format(data_source, current_date_str)

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '4g',
    "jars": ['/usr/lib/nzjdbc3.jar']
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name=script_name
)

month_str = datetime.strptime(current_date_str, '%Y-%m-%d').strftime('%Y%m')

output_dir = '/rawdata/msc/{}/date={}'.format(data_source.lower(), current_date_str)
sql = '''
( select CALL_TYPE
       , CALL_TYPE_DETAIL
       , CALLING_ISDN
       , IMSI
       , CALL_STA_TIME
       , DURATION
       , CALLED_ISDN
       , CELL_ID
       , SERVICE_CENTER
       , IC_ROUTE
       , OG_ROUTE
       , ORG_CALL_ID
       , REC_SEQ_NUM
       , CALLING_IMEI
       , DIAGNOSTICS
       , SMSRESULT
       , CAUSEFORTERM
	   , mess_type
	   , CALLED_ORG
	   
    from CDR_OWNER.CDRMSC_{}
    where date(CALL_STA_TIME) = to_date('{}', 'yyyy-MM-dd')
    and call_type in ('{}')
 ) table_alias
'''.format(month_str, current_date_str, data_source)

df = spark.read. \
    format("jdbc") \
    .option("url", "jdbc:netezza://10.3.4.121:5480/BIGDATA") \
    .option("user", "admin") \
    .option("password", "bigmbf@2018") \
    .option("dbtable", sql) \
    .option("driver", "org.netezza.Driver") \
    .option("fetchsize", 100000) \
    .load()

df.write.mode("overwrite").option('header', 'true').csv(output_dir, compression="bzip2")
