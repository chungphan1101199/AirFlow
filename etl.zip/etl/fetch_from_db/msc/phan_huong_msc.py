import sys

import pyspark.sql.functions as F
from pyspark.sql.window import Window

from etl.common import init_spark

current_date_str = sys.argv[1]
data_type = sys.argv[2]
script_name = 'airflow_phan_huong_msc_for_{}_{}'.format(data_type, current_date_str)

default_job_cfg = {
    "executor.instances": 2,
    "executor.cores": 4,
    "executor.memory": '8g',
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name=script_name
)

# Main logic
df_mnp_isdn = spark.read.format('csv').option("header", "true").load('/user/phan_huong/mnp_isdn.csv')
df_plmn_calltype = spark.read.format('csv').option("header", "true").load('/user/phan_huong/plmn_calltype.csv')
df_map_mnp = spark.read.format('csv').option("header", "true").load('/user/phan_huong/map_mnp.csv')
df_isdn_mnp_join = df_mnp_isdn.join(df_map_mnp, df_mnp_isdn['NET_OPERATOR_TO_ID'] == df_map_mnp['MNP_ID'], how='left')

df_isdn_mnp_join = df_isdn_mnp_join.select([
    'ISDN',
    'IN_NET_DATE',
    'OUT_NET_DATE',
    'PLMN_ID',
    'CALL_TYPE_ID',
    'new_CALL_TYPE']) \
    .withColumnRenamed('PLMN_ID', 'isdn_PLMN_ID') \
    .withColumnRenamed('CALL_TYPE_ID', 'isdn_CALL_TYPE_ID')

df_plmn_calltype = df_plmn_calltype.select([
    'PLMN_ID',
    'ISDN',
    'CALL_TYPE_ID',
    'EXACT',
    'new_CALL_TYPE'
]).withColumnRenamed('PLMN_ID', 'plmn_PLMN_ID') \
    .withColumnRenamed('CALL_TYPE_ID', 'plmn_CALL_TYPE_ID') \
    .withColumn('ISDN', F.trim(F.col('ISDN')))

input_dir = '/rawdata/msc/{}/date={}'.format(data_type.lower(), current_date_str)
output_dir = '/data/msc_phan_huong/{}/date={}'.format(data_type.lower(), current_date_str)
df = spark.read.format('csv').load(input_dir)

column_list = ['CALL_TYPE',
               'CALL_TYPE_DETAIL',
               'CALLING_ISDN',
               'IMSI',
               'CALL_STA_TIME',
               'DURATION',
               'CALLED_ISDN',
               'CELL_ID',
               'SERVICE_CENTER',
               'IC_ROUTE',
               'OG_ROUTE',
               'ORG_CALL_ID',
               'REC_SEQ_NUM',
               'CALLING_IMEI',
               'DIAGNOSTICS',
               'SMSRESULT',
               'CAUSEFORTERM',
               'MESS_TYPE',
               'CALLED_ORG']

df = df.toDF(*column_list).withColumn('row_id', F.monotonically_increasing_id()) \
    .withColumn('map_CALL_TYPE', F.when(F.col('CALL_TYPE') == "DV", 'OG').otherwise(F.col('CALL_TYPE')))

df = df.withColumn('CALL_STA_TIME', F.to_timestamp('CALL_STA_TIME')) \
    .withColumn('trim_CALLED_ISDN', F.regexp_replace('CALLED_ISDN', r'^[0]*', ''))

join_expr = ((df['trim_CALLED_ISDN'] == df_isdn_mnp_join['ISDN']) & (
        df_isdn_mnp_join['IN_NET_DATE'] <= df['CALL_STA_TIME']) &
             (df['CALL_STA_TIME'] <= F.coalesce(df_isdn_mnp_join['OUT_NET_DATE'], df['CALL_STA_TIME'])) &
             (df_isdn_mnp_join['new_CALL_TYPE'] == df['map_CALL_TYPE'])
             )

df_be_mnp = df.join(df_isdn_mnp_join, join_expr, how='left')

not_mnp_join_expr = (
        (F.isnull(df_be_mnp['isdn_PLMN_ID'])) &
        (F.isnull(df_be_mnp['isdn_CALL_TYPE_ID'])) &
        (df_be_mnp['map_CALL_TYPE'] == df_plmn_calltype['new_CALL_TYPE']) &
        (((df_be_mnp['CALLED_ISDN'] == df_plmn_calltype['ISDN']) & (df_plmn_calltype['EXACT'] == '1')) |
         ((df_be_mnp['CALLED_ISDN'].startswith(df_plmn_calltype['ISDN'])) & (df_plmn_calltype['EXACT'] == '0')))
)

df_join_mnp_and_not_mnp = df_be_mnp.join(df_plmn_calltype, not_mnp_join_expr, how='left')

df_join_mnp_and_not_mnp = df_join_mnp_and_not_mnp.withColumn(
    'length_of_match_isdn',
    F.length(df_plmn_calltype['ISDN']))

windowSpec = Window.partitionBy("row_id").orderBy(F.desc('IN_NET_DATE'), F.desc('length_of_match_isdn'),
                                                  F.desc('EXACT'))

df_join_mnp_and_not_mnp = df_join_mnp_and_not_mnp.withColumn("row_number", F.row_number().over(windowSpec)).where(
    F.col('row_number') == 1)

all_column_list = ['CALL_TYPE',
                   'CALL_TYPE_DETAIL',
                   'CALLING_ISDN',
                   'IMSI',
                   'CALL_STA_TIME',
                   'DURATION',
                   'CALLED_ISDN',
                   'CELL_ID',
                   'SERVICE_CENTER',
                   'IC_ROUTE',
                   'OG_ROUTE',
                   'ORG_CALL_ID',
                   'REC_SEQ_NUM',
                   'CALLING_IMEI',
                   'DIAGNOSTICS',
                   'SMSRESULT',
                   'CAUSEFORTERM',
                   'MESS_TYPE',
                   'CALLED_ORG',
                   'PLMN_ID',
                   'CALL_TYPE_ID'
                   ]

df_join_mnp_and_not_mnp = df_join_mnp_and_not_mnp \
    .withColumn('PLMN_ID', F.coalesce(df_be_mnp['isdn_PLMN_ID'], df_plmn_calltype['plmn_PLMN_ID'])) \
    .withColumn('CALL_TYPE_ID', F.coalesce(df_be_mnp['isdn_CALL_TYPE_ID'], df_plmn_calltype['plmn_CALL_TYPE_ID'])) \
    .select(*all_column_list)

# Write result to csv
df_join_mnp_and_not_mnp.write.mode("overwrite").option("header", "true").csv(
    output_dir, compression='snappy')
