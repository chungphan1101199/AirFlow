import sys
from datetime import datetime

current_date_str = sys.argv[1]
first_date_of_month_str = (
    (datetime.strptime(current_date_str, '%Y-%m-%d')).replace(day=1)).strftime(
    '%Y-%m-%d')
script_name = 'airflow_fetch_for_cell_id_{}'.format(first_date_of_month_str)

from etl.common import init_spark

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '4g',
    "jars": ['/usr/lib/ojdbc6.jar']
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name=script_name
)

output_dir = '/rawdata/cell_id/date={}'.format(first_date_of_month_str)
sql = '''
( 
SELECT file_date,
       mcc,
       mnc,
       lac,
       cell_id,
       cell_name,
       CASE
          WHEN INSTR (REPLACE (REPLACE (cell_name, '_LTE', ''), 'LTE', ''),
                      '_'
                     ) <> 0
          THEN
             SUBSTR (
                REPLACE (REPLACE (cell_name, '_LTE', ''), 'LTE', ''),
                1,
                  LENGTH (
                     REPLACE (REPLACE (cell_name, '_LTE', ''), 'LTE', ''))
                - 2)
          ELSE
             SUBSTR (
                REPLACE (REPLACE (cell_name, '_LTE', ''), 'LTE', ''),
                1,
                  LENGTH (
                     REPLACE (REPLACE (cell_name, '_LTE', ''), 'LTE', ''))
                - 1)
       END
          bts_name,
       location_number,
       b.center_from_2015 center,
       b.province_code,
       b.district_code,
       b.province,
       b.district,
       address_detail,
       address_detail_english,
       latitude,
       longitude,
       cell_type,
       azimuth,
       imported_date
  FROM report.cell_info_cells@crc11g a, report.address b
 WHERE a.province = b.province_code AND a.district = b.district_code                
 ) table_alias
'''

df = spark.read. \
    format("jdbc") \
    .option("url", "jdbc:oracle:thin:@10.50.8.21:1521:REPORT1") \
    .option("user", "fintech") \
    .option("password", "fintech") \
    .option("dbtable", sql) \
    .option("driver", "oracle.jdbc.driver.OracleDriver") \
    .option("fetchsize", 100000) \
    .load()

df.write.mode("overwrite").option('header', 'true').csv(output_dir)
