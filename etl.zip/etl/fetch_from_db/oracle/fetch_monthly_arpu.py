import sys
from datetime import datetime

from dateutil.relativedelta import relativedelta

from etl.common import init_spark

current_date_str = sys.argv[1]
first_date_of_previous_month_str = (
    (datetime.strptime(current_date_str, '%Y-%m-%d') - relativedelta(months=1)).replace(day=1)).strftime(
    '%Y-%m-%d')

data_source = 'monthly_arpu'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '4g',
    "jars": ['/usr/lib/ojdbc6.jar']
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_fetch_for_{}_{}'.format(data_source, first_date_of_previous_month_str)
)

output_dir = '/rawdata/monthly_arpu/date={}'.format(first_date_of_previous_month_str)
sql = '''
( 
SELECT /*+ full(t) parallel(t,32,2) */
          *
     from report.revenue_sub_monthly t
        WHERE issue_month = to_date('{}', 'yyyy-MM-dd')
 ) table_alias
'''.format(first_date_of_previous_month_str)

print('{}'.format(sql))

df = spark.read. \
    format("jdbc") \
    .option("url", "jdbc:oracle:thin:@10.50.8.21:1521:REPORT1") \
    .option("user", "fintech") \
    .option("password", "fintech") \
    .option("dbtable", sql) \
    .option("driver", "oracle.jdbc.driver.OracleDriver") \
    .option("fetchsize", 100000) \
    .load()

df.write.mode("overwrite").option('header', 'true').csv(output_dir, compression="bzip2")
