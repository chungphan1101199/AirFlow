import sys
from datetime import datetime, timedelta

from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = 'vasp_del'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '4g',
    "jars": ['/usr/lib/ojdbc6.jar']
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_fetch_for_{}_{}'.format(data_source, current_date_str)
)

month_str = datetime.strptime(current_date_str, '%Y-%m-%d').strftime('%Y%m')
next_date_str = (datetime.strptime(current_date_str, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')

output_dir = '/rawdata/vasp_del/date={}'.format(current_date_str)
sql = '''
( 
    SELECT *
  FROM report.vasp_register_del
    where end_datetime >= to_date('{}','yyyy-MM-dd') 
    and end_datetime < to_date('{}','yyyy-MM-dd')
  
 ) table_alias
'''.format(current_date_str, next_date_str)
print('{}'.format(sql))
df = spark.read. \
    format("jdbc") \
    .option("url", "jdbc:oracle:thin:@10.50.8.21:1521:REPORT1") \
    .option("user", "fintech") \
    .option("password", "fintech") \
    .option("dbtable", sql) \
    .option("driver", "oracle.jdbc.driver.OracleDriver") \
    .option("fetchsize", 100000) \
    .load()

df.write.mode("overwrite").option('header', 'true').csv(output_dir, compression="bzip2")
