import datetime
import sys

from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = 'icc_ic_call'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '4g',
    "jars": ['/usr/lib/ojdbc6.jar']
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_fetch_for_{}_{}'.format(data_source, current_date_str)
)

next_date = datetime.datetime.strptime(current_date_str, '%Y-%m-%d') + datetime.timedelta(days=1)
next_date_str = next_date.strftime('%Y-%m-%d')

sql = '''
(
select MOB_PROFILE acc_profile,

AMOUNT_SWAPPED,

BONUS_CREDIT2_CONSUMED,

BONUS_CREDIT2_REMAINING,

BONUS_CREDIT3_CONSUMED,

BONUS_CREDIT3_REMAINING,

BONUS_IRA_CONSUMED,

BONUS_IRA_REMAINING,

BONUS_IRB_CONSUMED,

BONUS_IRB_REMAINING,

'' bonus_IRSMS_consumed,

'' bonus_IRSMS_remaining,

BONUS_IRVS_CONSUMED,

BONUS_IRVS_REMAINING,

BONUS_KM1_CONSUMED,

BONUS_KM1_REMAINING,

BONUS_KM1T_CONSUMED,

BONUS_KM1T_REMAINING,

'' bonus_KM1V_consumed,

'' bonus_KM1V_remaining,

BONUS_KM2_CONSUMED,

BONUS_KM2_REMAINING,

BONUS_KM2T_CONSUMED,

BONUS_KM2T_REMAINING,

'' bonus_KM2V_consumed,

'' bonus_KM2V_remaining,

BONUS_KM3_CONSUMED,

BONUS_KM3_REMAINING,

BONUS_KM3T_CONSUMED,

BONUS_KM3T_REMAINING,

'' bonus_KM3V_consumed,

'' bonus_KM3V_remaining,

BONUS_KM4_CONSUMED,

BONUS_KM4_REMAINING,

BONUS_KM4T_CONSUMED,

BONUS_KM4T_REMAINING,

'' bonus_KM4V_consumed,

'' bonus_KM4V_remaining,

BONUS_KMDK1_CONSUMED,

BONUS_KMDK1_REMAINING,

BONUS_KMDK2_CONSUMED,

BONUS_KMDK2_REMAINING,

BONUS_KMDK3_CONSUMED,

BONUS_KMDK3_REMAINING,

BONUS_KMDK4_CONSUMED,

BONUS_KMDK4_REMAINING,

'' bonus_TK1_consumed,

'' bonus_TK1_remaining,

BUNDLE_CREDIT1_CONSUMED,

BUNDLE_CREDIT1_REMAINING,

'' bundle_CS_consumed,

'' bundle_CS_remaining,

'' bundle_DATA_31_consumed,

'' bundle_DATA_31_remaining,

'' bundle_DATA_6_remaining,

'' bundle_DATA_6_consumed,

'' bundle_DATA_KM1_consumed,

'' bundle_DATA_KM1_remaining,

'' bundle_DATA_LN_consumed,

'' bundle_DATA_LN_remaining,

'' bundle_DATA_VC_consumed,

'' bundle_DATA_VC_remaining,

'' bundle_DATA5_consumed,

'' bundle_DATA5_remaining,

'' bundle_DataDem_consumed,

'' bundle_DataDem_remaining,

'' bundle_DataZ1_consumed,

'' bundle_DataZ1_remaining,

'' bundle_DataZ2_consumed,

'' bundle_DataZ2_remaining,

'' bundle_DataZ3_consumed,

'' bundle_DataZ3_remaining,

BUNDLE_DK_CONSUMED,

BUNDLE_DK_REMAINING,

BUNDLE_GPRS0_CONSUMED,

BUNDLE_GPRS0_REMAINING,

'' bundle_GROUP_consumed,

'' bundle_GROUP_remaining,

BUNDLE_IRD_CONSUMED,

BUNDLE_IRD_REMAINING,

BUNDLE_KM_CONSUMED,

BUNDLE_KM_REMAINING,

'' bundle_KM99T_consumed,

'' bundle_KM99T_remaining,

'' bundle_KMKNDL_consumed,

'' bundle_KMKNDL_remaining,

BUNDLE_KMPACK_CONSUMED,

BUNDLE_KMPACK_REMAINING,

BUNDLE_LM_CONSUMED,

BUNDLE_LM_REMAINING,

'' bundle_LM_DL_consumed,

'' bundle_LM_DL_remaining,

'' bundle_LM1_consumed,

'' bundle_LM1_remaining,

'' bundle_LN_consumed,

'' bundle_LN_remaining,

'' bundle_mloyalty_consumed,

'' bundle_mloyalty_remaining,

BUNDLE_OP_CONSUMED,

BUNDLE_OP_REMAINING,

BUNDLE_PACKAGE_CONSUMED,

BUNDLE_PACKAGE_REMAINING,

BUNDLE_RM_CONSUMED,

BUNDLE_RM_REMAINING,

'' bundle_SMS_SP1_consumed,

'' bundle_SMS_SP1_remaining,

'' bundle_SMS_SP2_consumed,

'' bundle_SMS_SP2_remaining,

'' bundle_SMS3_consumed,

'' bundle_SMS3_remaining,

'' bundle_SMSRefill_consumed,

'' bundle_SMSRefill_remaining,

BUNDLE_THOAILM1_CONSUMED,

BUNDLE_THOAILM1_REMAINING,

BUNDLE_TK_AP1_CONSUMED,

BUNDLE_TK_AP1_REMAINING,

BUNDLE_TK_AP2_CONSUMED,

BUNDLE_TK_AP2_REMAINING,

'' bundle_VIDEO_consumed,

'' bundle_VIDEO_remaining,

BUNDLE_VNPT_CONSUMED,

BUNDLE_VNPT_REMAINING,

BUNDLE_VNPT1_CONSUMED,

BUNDLE_VNPT1_REMAINING,

BUNDLE_VOICE_KM1_CONSUMED,

BUNDLE_VOICE_KM1_REMAINING,

'' bundle_VOICE_LMZ_consumed,

'' bundle_VOICE_LMZ_remaining,

'' bundle_VOICE_SP1_consumed,

'' bundle_VOICE_SP1_remaining,

'' bundle_VOICE_SP2_consumed,

'' bundle_VOICE_SP2_remaining,

BUNDLE_VOICETH_CONSUMED,

BUNDLE_VOICETH_REMAINING,

BUNDLE_VORMO_IN_CONSUMED,

BUNDLE_VORMO_IN_REMAINING,

BUNDLE_WALLET1_CONSUMED,

BUNDLE_WALLET1_REMAINING,

BUNDLE_WALLET2_CONSUMED,

BUNDLE_WALLET2_REMAINING,

'' bundle_WALLET3_consumed,

'' bundle_WALLET3_remaining,

'' bundle_wifi_consumed,

'' bundle_wifi_remaining,

to_char(sta_datetime, 'dd/mm/yyyy hh24:mi:ss') call_sta_time,

CALL_TYPE_CDR call_type,

CALLED_NUMBER called_isdn,

CALLING_NUMBER calling_isdn,

CELL_ID,

'' correlation_identifier,

'' credit_before_adjustment,

CHARGE_CREDIT credit_charged,

REMAINING_CREDIT credit_remaining,

DAY_SWAPPED,

DURATION,

EVENT_TYPE_NAME,

FEE_SWAPPED,

FEE_NAME feeName,

IMSI,

LOCATION,

LOCATION_INDICATOR,

NET_ELEMENT_ID,

NET_ELEMENT_TRANS_ID,

'' network_service_id,

ORG_CALL_ID,

REASON_CODE,

'' Reseller_ID,

ROUTE_NUMBER,

SCRATCH_NUMBER,

SCRATCH_TYPE,

SCRATCH_VALUE,

SUB_TYPE SubScriber_type,

TARIFF_NAME,

'' topup_profile,

TRANSACTION_DESCRIPTION,

'' plmn_id,

'' call_type_id,

DISCARDED_CREDIT,

'' INSERVICERESULT

from crc4_ct.icc_ic_call@crc11g where sta_Datetime >= to_date('{}', 'yyyy-MM-dd') and sta_Datetime < to_date('{}', 'yyyy-MM-dd')
) table_alias
'''.format(current_date_str, next_date_str)

output_dir = '/rawdata/icc/icc_ic_call/date={}'.format(current_date_str)

df = spark.read. \
    format("jdbc") \
    .option("url", "jdbc:oracle:thin:@10.50.8.21:1521:REPORT1") \
    .option("user", "fintech") \
    .option("password", "fintech") \
    .option("dbtable", sql) \
    .option("driver", "oracle.jdbc.driver.OracleDriver") \
    .option("fetchsize", 100000) \
    .load()

df.write.mode("overwrite").option('header', 'true').csv(output_dir, compression="bzip2")