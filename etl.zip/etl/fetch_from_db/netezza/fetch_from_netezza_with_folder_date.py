import os
import sys

from etl.common import init_spark

current_date_str = sys.argv[1]
data_type = sys.argv[2]
script_name = 'airflow_fetch_from_netezza_for_' + data_type

from etl.common import init_spark

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '4g',
    "jars": ['/usr/lib/nzjdbc3.jar']
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name=script_name
)

output_dir = '/rawdata/netezza/{}/date={}'.format(data_type, current_date_str)
sql = '''
(select * from {} where folder_date = to_date('{}', 'yyyy-MM-dd') ) table_alias
'''.format(data_type, current_date_str)

df = spark.read. \
    format("jdbc") \
    .option("url", "jdbc:netezza://10.3.4.121:5480/BIGDATA") \
    .option("user", "admin") \
    .option("password", "bigmbf@2018") \
    .option("dbtable", sql) \
    .option("driver", "org.netezza.Driver") \
    .option("fetchsize", 10000) \
    .load()

df.write.mode("overwrite").option('header', 'true').csv(output_dir, compression="bzip2")
