import os
import sys
from datetime import datetime

from etl.common import init_spark

current_date_str = sys.argv[1]
data_source = 'vlr_daily'

default_job_cfg = {
    "executor.instances": 1,
    "executor.cores": 2,
    "executor.memory": '4g',
    "jars": ['/usr/lib/nzjdbc3.jar']
}

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='airflow_fetch_for_{}_{}'.format(data_source, current_date_str)
)

# launching PySpark application
execfile(os.path.join(spark_home, 'python/pyspark/shell.py'))

month_str = datetime.strptime(current_date_str, '%Y-%m-%d').strftime('%Y%m')

output_dir = '/rawdata/vlr_daily/date={}'.format(current_date_str)
sql = '''
(   SELECT START_DATE
       , ISDN
       , IMSI
       , SW_STATE
       , CELL_ID
       , IMEI
       , SWITCH_ID
       , AREA_BY_CELL_ID
       , STATUS_GPRS
       , folder_date date_id
  FROM bigdata.CDR_OWNER.DUMP_VLR_2020
  where folder_date = to_date('{}', 'yyyy-MM-dd')
 ) table_alias
'''.format(current_date_str)

df = spark.read. \
    format("jdbc") \
    .option("url", "jdbc:netezza://10.3.4.121:5480/BIGDATA") \
    .option("user", "admin") \
    .option("password", "bigmbf@2018") \
    .option("dbtable", sql) \
    .option("driver", "org.netezza.Driver") \
    .option("fetchsize", 100000) \
    .load()

df.write.mode("overwrite").option('header', 'true').csv(output_dir, compression="bzip2")
