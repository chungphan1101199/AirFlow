import sys

from etl.fetch_from_db.utils import hdfs

current_date_str = sys.argv[1]
data_type = sys.argv[2]

# Sample file path: /ftp/rawdata/icc/icc_gprs/icc_gprs.2019-10-31.csv
file_path = '/ftp/rawdata/icc/{}/{}.{}.csv.bz2'.format(data_type, data_type, current_date_str)
hdfs_dir = '/rawdata/icc/{}/date={}'.format(data_type, current_date_str)

if hdfs.check_dir_exist(hdfs_dir):
    print ('Directory already exist in HDFS: {}'.format(hdfs_dir))
else:
    print ('Directory not exist in HDFS, execute make dir: {}'.format(hdfs_dir))
    hdfs.mkdir_hdfs(hdfs_dir)

hdfs_file_path = '/rawdata/icc/{}/date={}/{}.{}.csv.bz2'.format(data_type, current_date_str, data_type,
                                                                current_date_str)
print('hdfs file file path: {}'.format(hdfs_file_path))
if hdfs.check_file_exist(hdfs_file_path):
    print ('File already exist in HDFS: {}'.format(hdfs_file_path))
else:
    print ('File not exist in HDFS, try to copy from local: {}'.format(hdfs_file_path))
    if hdfs.move_file_to_hdfs(file_path, hdfs_dir):
        sys.exit(0)
    else:
        print ('Cannot move file to HDFS for {} to {}', file_path, hdfs_dir)
        sys.exit(1)
