import subprocess
import sys
import os
from etl.fetch_from_db.utils import hdfs

current_date_str = sys.argv[1]
data_type = sys.argv[2]

# Sample file path: /ftp/rawdata/icc/icc_gprs/icc_gprs.2019-10-31.csv
file_path = '/ftp/rawdata/icc/{}/{}.{}.csv'.format(data_type, data_type, current_date_str)
compressed_file_path = '/ftp/rawdata/icc/{}/{}.{}.csv.bz2'.format(data_type, data_type, current_date_str)

# Sample bz2 file path: /ftp/rawdata/icc/icc_gprs/icc_gprs.2019-10-31.csv.bz2

hdfs_file_path = '/rawdata/icc/{}/date={}/{}.{}.csv.bz2'.format(data_type, current_date_str, data_type,
                                                                current_date_str)

if hdfs.check_file_exist(hdfs_file_path):
    print ('File already exist in HDFS: {}'.format(hdfs_file_path))
else:
    print ('File not exist in HDFS, try to compress local file: {}'.format(hdfs_file_path))
    if os.path.isfile(compressed_file_path):
        print("Compress file path is already exist: {}".format(compressed_file_path))
        print("Do nothing")
    else:
        print("Compress file path not exist, try to compress")
        print ('File to compress: {}'.format(file_path))
        args = ['bzip2', '-fv', file_path]
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.communicate()
        sys.exit(proc.returncode)
