import os
import subprocess
import sys

current_date_str = sys.argv[1]
data_type = sys.argv[2]

# Sample file path: /ftp/rawdata/icc/icc_gprs/icc_gprs.2019-10-31.csv
file_path = '/ftp/rawdata/icc/{}/{}.{}.csv.bz2'.format(data_type, data_type, current_date_str)
print("File path: {}".format(file_path))

if os.path.isfile(file_path):
    print("File exists and is readable")
    args = ['rm', '-rfv', file_path]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc.communicate()
    sys.exit(proc.returncode)
else:
    print("Either the file is missing, not delete")
