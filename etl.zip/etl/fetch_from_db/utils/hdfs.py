import subprocess


# move file to HDFS
def move_file_to_hdfs(file_path, hdfs_file_path):
    try:
        args = ['hdfs', 'dfs', '-put', '-f', file_path, hdfs_file_path]
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        proc.communicate()
        return proc.returncode == 0
    except Exception as e:
        print(e)
        return False


def check_dir_exist(dir_path):
    args = ['hdfs', 'dfs', '-test', '-d', dir_path]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc.communicate()
    return proc.returncode == 0


def get_merge_file_to_local(hdfs_dir_path, local_file_path):
    args = ['hdfs', 'dfs', '-getmerge', '-nl', '-skip-empty-file', hdfs_dir_path, local_file_path]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc.communicate()
    return proc.returncode == 0


def check_file_exist(file_path):
    args = ['hdfs', 'dfs', '-test', '-f', file_path]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc.communicate()
    return proc.returncode == 0


def mkdir_hdfs(dir_path):
    args = ['hdfs', 'dfs', '-mkdir', dir_path]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    proc.communicate()
    return proc.returncode == 0
