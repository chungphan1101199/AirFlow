import csv
import datetime as datetime

import cx_Oracle


def fetch(sql, file_path):
    dsn_tns = '''(DESCRIPTION =
        (ADDRESS_LIST =
          (ADDRESS = (PROTOCOL = TCP)(HOST = 10.50.8.22)(PORT = 1521))
          (ADDRESS = (PROTOCOL = TCP)(HOST = 10.50.8.27)(PORT = 1521))
        )
        (CONNECT_DATA =
          (SERVICE_NAME = report)
        )
      )'''

    connection = cx_Oracle.connect(user='fintech', password='fintech', dsn=dsn_tns)
    cursor = connection.cursor()
    cursor.arraysize = 100000
    print(sql)

    print('{:<20}:{}'.format('start: ', datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
    cursor.execute(sql)

    index = 0
    with open(file_path, "wb") as fout:
        writer = csv.writer(fout)
        writer.writerow([i[0] for i in cursor.description])  # heading row
        while True:
            rows = cursor.fetchmany()
            if not rows:
                break
            for row in rows:
                if index == 0:
                    print('{:<20}:{}'.format(str(index), datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
                index = index + 1
                if index % 1000000 == 0:
                    print('{:<20}:{}'.format(str(index), datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
                writer.writerow(row)

    print('{:<20}:{}'.format(str(index), datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
    print('{:<20}:{}'.format('end: ', datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")))

    cursor.close()
    connection.close()
