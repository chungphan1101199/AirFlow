# coding: utf-8

import logging
import os
import sys
from datetime import datetime, timedelta

from pyspark.sql import functions as F

from etl.common import init_spark
from etl.check_data.data_metrics import DataPoint, InFluxClientCic
from etl.common.config import read_config_service, read_column_list_service

handler = logging.StreamHandler(stream=sys.stdout)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger = logging.getLogger("Daily Report")
logger.addHandler(handler)
logger.setLevel("DEBUG")

data_source = sys.argv[1]
start_date_str = sys.argv[2]
start_date = datetime.strptime(start_date_str, "%Y-%m-%d")

try:
    num_date = int(sys.argv[3])
except:
    num_date = 1

metric_db = "daily_data_metric"
inFluxClientCic = InFluxClientCic(
    metric_db=metric_db
)

# get Spark resource config
default_job_cfg = {
    'master': 'yarn',
    "executor.instances": 1,
    "executor.cores": 16,
    "executor.memory": '8g',
    'driver.cores': 1,
    'driver.memory': '1g',
}

logger.debug('default_job_cfg : {}'.format(default_job_cfg))

spark = init_spark.setup(
    job_cfg=default_job_cfg,
    script_name='daily_metric_{}_{}'.format(data_source, start_date_str)
)

raw_data_path_prefix = read_config_service.read_data_path()[data_source]['raw_data_path_prefix']
column_list = read_column_list_service.get_column_list_for(data_source)

for current_date in (start_date + timedelta(n) for n in range(num_date)):
    current_date_str = current_date.strftime('%Y-%m-%d')
    input_dir = raw_data_path_prefix + current_date_str
    print(input_dir)

    try:
        df = spark.read.csv(input_dir).toDF(*column_list)
    except Exception as ex:
        print ('Exception when read from path: {}'.format(input_dir))
        print (ex)
        print ('Continue next date')
        continue

    total_count = df.count()

    # count
    dailyDp = DataPoint(metric="rows_count", time=current_date, fields={"value": total_count},
                        tags={"data_source": data_source})
    logger.debug("total row count: {}".format(total_count))
    inFluxClientCic.write_point(dailyDp)

    # get config
    config = read_config_service.read_column_types_for_report()[data_source]
    logger.debug("config info {}".format(config))
    list_categorical_columns = config["categorical_columns"]
    logger.debug("list categorical columns {}".format(list_categorical_columns))

    # Calculate distinct value for categorical attribute
    for column in config['categorical_columns']:
        distinct_value = df.agg(F.approx_count_distinct(column, rsd=0.01)).collect()[0][0]
        logger.debug("{} {} - {}".format('distinct value count: ', column, distinct_value))
        dailyDp = DataPoint(metric="distinct_value_count", time=current_date,
                            fields={"value": distinct_value},
                            tags={"data_source": data_source, "column_name": column})
        inFluxClientCic.write_point(dailyDp)

    # Calculate null count for all categorical column
    null_count_stats = df.select(
        [F.count(F.when(F.col(c).isNull(), c)).alias(c) for c in list_categorical_columns]).collect()
    logger.info(null_count_stats)
    data_point = null_count_stats[0].asDict()
    logger.info(data_point)
    for column in list_categorical_columns:
        null_count = int(data_point[column])
        print('column: {} null_count: {}'.format(column, null_count))
        nullCountDp = DataPoint(metric="null_count", time=current_date,
                                fields={"value": null_count},
                                tags={"data_source": data_source, "column_name": column})
        inFluxClientCic.write_point(nullCountDp)

    # do quantile for numeric column only
    list_numeric_columns = config["numeric_columns"]
    logger.debug("list numeric_columns {}".format(list_numeric_columns))

    quantile = df.stat.approxQuantile(list_numeric_columns, [0.01, 0.25, 0.50, 0.75, 0.99], relativeError=0.01)
    measurement_name_map = ["1%_value", "25%_value", "50%_value", "75%_value", "99%_value"]
    for index, quantile_value in enumerate(quantile):
        column = list_numeric_columns[index]
        for quantile_index, quantile_value in enumerate(quantile[index]):
            measurement_name = measurement_name_map[quantile_index]

            dailyDp = DataPoint(metric=measurement_name, time=current_date,
                                fields={"value": float(quantile_value)},
                                tags={"data_source": data_source, "column_name": column})
            logger.debug("{} Data type {} value {}".format(measurement_name, column, quantile_value))
            inFluxClientCic.write_point(dailyDp)
