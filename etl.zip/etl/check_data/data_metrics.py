from influxdb import InfluxDBClient
from pytz import reference
from datetime import date, datetime

LOCAL_TZ = reference.LocalTimezone()


########################################################################
# DataPoint is a point in a metrics flow, can have multiple attribute.
#   metric: name of the metrics.
#   time: timestamps of the data point, can be either a datetime.date or datetime.datetime.
#   fields: a dictionary of attributes: name->value
#   tags: special attributes that used to group data.
########################################################################
class DataPoint:
    def __init__(self, metric, time, fields, tags=None):
        self.metric = metric
        self.time = time
        self.fields = fields
        self.tags = tags

    # Simple datapoint only have one with one attribute named "value".
    @classmethod
    def simple(lcs, metric, time, value, tags=None):
        return lcs(metric, time, {"value": value}, tags)

    def standardize(self, dt):
        if isinstance(dt, date) and not isinstance(dt, datetime):
            dt = datetime.combine(dt, datetime.min.time())

        local_dt = dt.replace(tzinfo=LOCAL_TZ)
        return local_dt

    def to_json(self):
        time = self.standardize(self.time)
        tags = {}
        if self.tags is not None:
            tags = dict(tags.items() + self.tags.items())
        return {
            "measurement": self.metric,
            "tags": tags,
            "time": time.isoformat(),
            "fields": self.fields
        }


class InFluxClientCic:
    def __init__(self, metric_db):
        username = 'admin'
        password = 'b323ce275240e7f7cc8167fa'
        host = '10.3.7.191'
        port = 8086

        self.username = username
        self.password = password
        self.metric_db = metric_db
        self.host = host
        self.port = port
        self.influxClient = InfluxDBClient(host, port, username, password, metric_db)

    def write_point(self, dp):
        json = [dp.to_json()]
        self.write(json)

    def write_points(self, dps):
        json = list(map(lambda dp: dp.to_json(), dps))
        self.write(json)

    def write(self, json_body):
        # print json_body
        self.influxClient.write_points(json_body)

    def clear_metric(self, metric):
        self.influxClient.drop_measurement(metric)
