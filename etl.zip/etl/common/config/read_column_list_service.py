
def get_column_list_for(data_source):
    if data_source == 'smo':
        return ['CALL_TYPE',
                'CALL_TYPE_DETAIL',
                'CALLING_ISDN',
                'IMSI',
                'CALL_STA_TIME',
                'DURATION',
                'CALLED_ISDN',
                'CELL_ID',
                'SERVICE_CENTER',
                'IC_ROUTE',
                'OG_ROUTE',
                'ORG_CALL_ID',
                'REC_SEQ_NUM',
                'CALLING_IMEI',
                'DIAGNOSTICS',
                'SMSRESULT',
                'CAUSEFORTERM',
                'MESS_TYPE',
                'CALLED_ORG']
