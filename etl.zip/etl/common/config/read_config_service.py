import os
import json


def read_config(config_name):
    path = os.path.join(os.path.dirname(__file__), config_name)
    print (path)
    with open(path) as file:
        return json.load(file)


def read_column_types_for_report():
    return read_config('column_types_for_report.json')

def read_data_path():
    return read_config('data_path.json')
