import subprocess


def execute(args):
    print('commands: {}'.format(args))
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = proc.communicate()
    print('stdout: {}'.format(stdout))
    print('stderr: {}'.format(stderr))
    return_code = proc.returncode
    print('return_code: {}'.format(return_code))
    return return_code
